import '../models/post.dart';

class PostService {
  static final List<Post> posts = [
    Post(
      username: 'Alice',
      content: 'Hello Flutter developers!',
      likes: 12,
    ),
    Post(
      username: 'John',
      content: 'Building my first social media app.',
      likes: 7,
    ),
  ];

  static void addPost(Post post) {
    posts.insert(0, post);
  }
}