import 'package:flutter/material.dart';
import '../models/post.dart';
import 'dart:io';
import 'package:flutter/foundation.dart';

class PostCard extends StatelessWidget {
  final Post post;
  final VoidCallback refresh;

  const PostCard({
    super.key,
    required this.post,
    required this.refresh,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 6,
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                      const CircleAvatar(
                  child: Icon(Icons.person),
                ),
                const SizedBox(width: 10),
                Text(
                  post.username,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            if (post.content.isNotEmpty)
            Text(post.content),

          if (post.imagePath != null)
            Padding(
              padding: const EdgeInsets.only(top: 16),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: kIsWeb
                    ? Image.network(
                        post.imagePath!,
                        height: 250,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      )
                    : Image.file(
                        File(post.imagePath!),
                        height: 250,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    if (post.isLiked) {
                      post.likes--;
                    } else {
                      post.likes++;
                    }

                    post.isLiked = !post.isLiked;
                    refresh();
                  },
                  icon: Icon(
                    post.isLiked
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: post.isLiked ? Colors.red : null,
                  ),
                ),
                Text('${post.likes} likes'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}