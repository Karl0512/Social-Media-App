import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/post.dart';
import '../services/post_service.dart';
import '../widgets/post_card.dart';

class FeedScreen extends StatefulWidget {
  final String username;

  const FeedScreen({
    super.key,
    required this.username,
  });

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final TextEditingController postController = TextEditingController();

  String? selectedImage;

  Future<void> pickImage() async {
    final ImagePicker picker = ImagePicker();

    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
    );

    if (image != null) {
      setState(() {
        selectedImage = image.path;
      });
    }
  }

  void createPost() {
    if (postController.text.trim().isEmpty &&
        selectedImage == null) {
      return;
    }

    PostService.addPost(
      Post(
        username: widget.username,
        content: postController.text.trim(),
        imagePath: selectedImage,
      ),
    );

    postController.clear();

    setState(() {
      selectedImage = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Social Feed'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      const CircleAvatar(
                        child: Icon(Icons.person),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextField(
                          controller: postController,
                          decoration: const InputDecoration(
                            hintText: 'Share something...',
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                    ],
                  ),

                  if (selectedImage != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: kIsWeb
                            ? Image.network(
                                selectedImage!,
                                height: 200,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              )
                            : Image.file(
                                File(selectedImage!),
                                height: 200,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                      ),
                    ),

                  const SizedBox(height: 12),

                  Row(
                    children: [
                      TextButton.icon(
                        onPressed: pickImage,
                        icon: const Icon(Icons.image_outlined),
                        label: const Text('Photo'),
                      ),
                      const Spacer(),
                      ElevatedButton(
                        onPressed: createPost,
                        child: const Text('Post'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: PostService.posts.length,
              itemBuilder: (context, index) {
                return PostCard(
                  post: PostService.posts[index],
                  refresh: () => setState(() {}),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}